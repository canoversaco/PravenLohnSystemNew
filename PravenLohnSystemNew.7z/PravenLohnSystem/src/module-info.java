/**
 * 
 */
/**
 * @author cani1
 *
 */
module PravenLohnSystem {
	requires org.bukkit;
	requires java.logging;
	requires Vault;
}